---
title: Sonuçlar
layout: turnuva
---
