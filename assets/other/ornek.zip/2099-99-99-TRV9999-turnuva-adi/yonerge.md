---
title: Yönerge
layout: turnuva
---
